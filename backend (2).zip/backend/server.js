
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;
const DB_FILE = path.join(__dirname, 'database.json');

// Middleware
app.use(cors());
app.use(bodyParser.json({ limit: '50mb' })); 

// Helper to read DB
function readDb() {
    if (!fs.existsSync(DB_FILE)) {
        const initialData = {
            students: [{
                id: '1',
                fullName: 'Sean Nyakutira',
                email: '2024061311@edenuniversity.education',
                studentId: '2024061311',
                phone: '+260776950796',
                program: 'Bachelor of Science in ICT',
                year: '2',
                school: 'School of Education, Humanities and Social Sciences',
                academicSession: 'GER 2025',
                registrationStatus: 'Registered',
                studentSponsor: 'SELF',
                accommodation: 'NON-RESIDENT',
                remark: 'NO COMMENT ADDED YET',
                courses: ['Mathematics', 'Physics', 'Chemistry', 'Computer Science'],
                password: '#Sean2006',
                profilePhoto: null,
                results: [
                    { course: 'Mathematics', grade: 'A', score: 85 },
                    { course: 'Physics', grade: 'B', score: 78 },
                    { course: 'Chemistry', grade: 'A', score: 88 }
                ],
                finance: {
                    totalFees: 15780.00,
                    amountPaid: 10147.00,
                    balance: 5633.00,
                    transactions: []
                },
                createdAt: new Date('2025-10-06').toISOString(),
                accountStatus: 'active'
            }],
            adminAccount: {
                username: 'Administrator',
                password: '#Sean@7053'
            }
        };
        fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2));
        return initialData;
    }
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}

// Helper to write DB
function writeDb(data) {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

// Routes

// Get all students
app.get('/api/students', (req, res) => {
    const db = readDb();
    res.json(db.students);
});

// Add a student
app.post('/api/students', (req, res) => {
    const db = readDb();
    const newStudent = req.body;
    db.students.push(newStudent);
    writeDb(db);
    res.status(201).json(newStudent);
});

// Update a student
app.put('/api/students/:id', (req, res) => {
    const db = readDb();
    const { id } = req.params;
    const updatedData = req.body;
    
    const index = db.students.findIndex(s => s.id === id);
    if (index !== -1) {
        db.students[index] = { ...db.students[index], ...updatedData };
        writeDb(db);
        res.json(db.students[index]);
    } else {
        res.status(404).json({ error: 'Student not found' });
    }
});

// Delete a student
app.delete('/api/students/:id', (req, res) => {
    const db = readDb();
    const { id } = req.params;
    
    const initialLength = db.students.length;
    db.students = db.students.filter(s => s.id !== id);
    
    if (db.students.length < initialLength) {
        writeDb(db);
        res.json({ success: true });
    } else {
        res.status(404).json({ error: 'Student not found' });
    }
});

// Get Admin Account
app.get('/api/admin', (req, res) => {
    const db = readDb();
    res.json(db.adminAccount);
});

// Update Admin Account (password change)
app.post('/api/admin', (req, res) => {
    const db = readDb();
    const newAdminData = req.body;
    db.adminAccount = { ...db.adminAccount, ...newAdminData };
    writeDb(db);
    res.json(db.adminAccount);
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
